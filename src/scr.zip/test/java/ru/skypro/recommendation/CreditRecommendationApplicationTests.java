package ru.skypro.recommendation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditRecommendationApplicationTests {

	@Test
	void contextLoads() {
	}

}
