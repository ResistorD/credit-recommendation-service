package ru.skypro.recommendation.credit_recommendation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditRecommendationApplicationTests {

	@Test
	void contextLoads() {
	}

}
