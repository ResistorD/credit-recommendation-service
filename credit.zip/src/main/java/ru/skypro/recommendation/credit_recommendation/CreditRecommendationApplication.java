package ru.skypro.recommendation.credit_recommendation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreditRecommendationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditRecommendationApplication.class, args);
	}

}
